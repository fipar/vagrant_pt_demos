def test_suite():
    from unittest import TestSuite
    return TestSuite()
