#!/usr/bin/perl
# Call mtr in out-of-source build
$ENV{MTR_BINDIR} = "/home/jenkins/workspace/percona-server-5.5-binaries/label_exp/centos5-64/Percona-Server-5.5.27-rel28.1";
chdir("/home/jenkins/workspace/percona-server-5.5-binaries/label_exp/centos5-64/Percona-Server-5.5.27-rel28.0/mysql-test");
exit(system($^X, "/home/jenkins/workspace/percona-server-5.5-binaries/label_exp/centos5-64/Percona-Server-5.5.27-rel28.0/mysql-test/mysql-test-run.pl", @ARGV) >> 8);
