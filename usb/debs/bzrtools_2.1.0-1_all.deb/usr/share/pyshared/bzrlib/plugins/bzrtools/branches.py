from bzrlib import errors
from bzrlib.bzrdir import BzrDir
from bzrlib.transport import get_transport
from bzrtools import list_branches


def branches(location=None):
    if location is None:
        location = '.'
    t = get_transport(location)
    for branch in list_branches(t):
        print branch.base[len(t.base):].rstrip('/')
