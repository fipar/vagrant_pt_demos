from unittest import TestCase

from bzrlib.plugins.bzrtools import dotgraph

class TestNode(TestCase):

    def test_define_escapes_backslash(self):
        node = dotgraph.Node('AB', message=r'Slash\me')
        self.assertEqual(r'AB[shape="box" tooltip="Slash\\me" href="#"]',
                         node.define())
